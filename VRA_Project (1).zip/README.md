# VRA – Virtual Root Android (prototype 0.1.0)

Goal: an isolated guest Android with its own kernel and guest-only root, on an unrooted phone.

## Honest status
| Feature | Status |
|---|---|
| Hardware compatibility check (KVM, AVF flag, ABI, RAM, storage) | Implemented, unit-tested logic; device probe untested on hardware |
| Guest image / QEMU detection | Implemented, untested on hardware |
| Root policy store (grant, revoke, log) | Implemented, unit-tested. No guest enforcement |
| Isolation sharing flags | Implemented (stored policy only) |
| 13 screens | Implemented; guest-dependent screens show disabled state |
| QEMU launch, guest su, app installer, terminal, guest backup | NOT implemented |
| Google services | Not bundled; needs licensed image |

This build was not compiled here (no Flutter SDK or network in the authoring sandbox). The GitHub workflow compiles and runs tests; fix any first-build errors it reports.

## Reality of the goal
- Normal apps cannot use Android Virtualization Framework custom VMs.
- Most phones do not expose `/dev/kvm` to apps, so QEMU would run in slow software emulation.
- A container shares the host kernel, so it is never a separate Android kernel.

## Build
1. Create a GitHub repo and upload this folder.
2. Actions tab → "Build VRA release APK" → Run workflow.
3. Download `vra-release-apk` from the run. It is signed with the debug key; add your own signing for distribution.

Local: `cd frontend && flutter create --org dev.vra --platforms android . && ` copy `android_overlay` and `android_host/kotlin` as in the workflow, then `flutter run`.
