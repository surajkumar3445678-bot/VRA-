package dev.vra.host

import android.content.Context
import android.system.Os
import java.io.File

/** Locates guest files. Launching QEMU is not implemented yet and says so. */
object GuestManager {
    private fun image(ctx: Context) = File(ctx.filesDir, "guest/system.img")
    private fun qemu(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir, "libqemu.so")

    fun status(ctx: Context): Map<String, Any> {
        val img = image(ctx)
        return mapOf(
            "installed" to img.isFile,
            "imagePath" to img.absolutePath,
            "imageBytes" to (if (img.isFile) img.length() else 0L),
            "qemuPresent" to qemu(ctx).isFile,
        )
    }

    fun boot(ctx: Context): Map<String, Any> {
        if (!image(ctx).isFile)
            return mapOf("ok" to false, "reason" to "No guest image at ${image(ctx).absolutePath}.")
        if (!qemu(ctx).isFile)
            return mapOf("ok" to false, "reason" to "No QEMU binary packaged with this build.")
        return mapOf("ok" to false, "reason" to "Image and QEMU found, but the QEMU launcher is not implemented in this build, so nothing was started.")
    }

    private fun prepareLibLinks(ctx: Context): File {
        val dir = File(ctx.filesDir, "qemu-libs")
        dir.deleteRecursively()
        dir.mkdirs()
        val nat = ctx.applicationInfo.nativeLibraryDir
        ctx.assets.open("qemu_libmap.txt").bufferedReader().useLines { lines ->
            for (l in lines) {
                val p = l.split("=")
                if (p.size == 2 && p[0].isNotBlank()) {
                    val target = File(nat, p[1])
                    if (target.isFile) Os.symlink(target.absolutePath, File(dir, p[0]).absolutePath)
                }
            }
        }
        return dir
    }

    private fun runQemu(ctx: Context, q: File, linkDir: File, args: List<String>): String {
        val pb = ProcessBuilder(listOf(q.absolutePath) + args).redirectErrorStream(true)
        pb.environment()["LD_LIBRARY_PATH"] = linkDir.absolutePath + ":" + ctx.applicationInfo.nativeLibraryDir
        val p = pb.start()
        val out = StringBuilder()
        val t = Thread { p.inputStream.bufferedReader().forEachLine { out.appendLine(it) } }
        t.start()
        t.join(15000)
        if (t.isAlive) {
            p.destroy()
            return out.toString().trim() + "\n(timed out after 15 s)"
        }
        val code = p.waitFor()
        return out.toString().trim() + "\n(exit code $code)"
    }

    /** Runs the packaged QEMU for real and returns what it printed. Starts no guest. */
    fun qemuSmokeTest(ctx: Context): Map<String, Any> {
        val q = qemu(ctx)
        if (!q.isFile)
            return mapOf("ok" to false, "output" to "QEMU is not packaged in this build (libqemu.so missing).")
        return try {
            val linkDir = prepareLibLinks(ctx)
            val sb = StringBuilder()
            for (args in listOf(listOf("--version"), listOf("-accel", "help"))) {
                sb.append("$ qemu ${args.joinToString(" ")}\n")
                sb.append(runQemu(ctx, q, linkDir, args)).append("\n\n")
            }
            mapOf("ok" to true, "output" to sb.toString().trim())
        } catch (e: Exception) {
            mapOf("ok" to false, "output" to "Could not run QEMU: ${e.message}")
        }
    }
}
