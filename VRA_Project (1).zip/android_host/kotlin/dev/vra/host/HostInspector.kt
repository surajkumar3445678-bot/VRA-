package dev.vra.host

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.io.File

/** Reads real host facts. Nothing here requests or reports root. */
object HostInspector {
    fun hostInfo(ctx: Context): Map<String, Any> {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val st = StatFs(Environment.getDataDirectory().path)
        val kvm = File("/dev/kvm")
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        return mapOf(
            "kvmUsable" to (kvm.exists() && kvm.canRead() && kvm.canWrite()),
            "avfFeature" to ctx.packageManager.hasSystemFeature("android.software.virtualization_framework"),
            "arm64" to Build.SUPPORTED_ABIS.contains("arm64-v8a"),
            "sdk" to Build.VERSION.SDK_INT,
            "ramMb" to (mi.totalMem / (1024 * 1024)).toInt(),
            "freeStorageMb" to (st.availableBytes / (1024 * 1024)).toInt(),
            "kernel" to (System.getProperty("os.version") ?: "unknown"),
            "abi" to abi,
            "model" to "${Build.MANUFACTURER} ${Build.MODEL}",
        )
    }
}
