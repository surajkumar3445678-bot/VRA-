# virtual_root
Implemented: policy store (`frontend/lib/root_policy.dart`) with grant, revoke, request and log, tested.
Not implemented: the guest-side `su` daemon that consults the policy. Until it exists, VRA does not claim root works.
