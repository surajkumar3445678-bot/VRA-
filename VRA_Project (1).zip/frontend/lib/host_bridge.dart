import 'package:flutter/services.dart';

class HostBridge {
  static const _ch = MethodChannel('dev.vra/host');

  static Future<Map<dynamic, dynamic>> hostInfo() async =>
      (await _ch.invokeMethod<Map<dynamic, dynamic>>('hostInfo')) ?? {};

  /// {installed: bool, imagePath: String, qemuPresent: bool, imageBytes: int}
  static Future<Map<dynamic, dynamic>> guestStatus() async =>
      (await _ch.invokeMethod<Map<dynamic, dynamic>>('guestStatus')) ?? {};

  /// {ok: bool, reason: String}
  static Future<Map<dynamic, dynamic>> bootGuest() async =>
      (await _ch.invokeMethod<Map<dynamic, dynamic>>('bootGuest')) ?? {};

  /// {ok: bool, output: String}. Runs the packaged QEMU binary; starts no guest.
  static Future<Map<dynamic, dynamic>> qemuSmokeTest() async =>
      (await _ch.invokeMethod<Map<dynamic, dynamic>>('qemuSmokeTest')) ?? {};
}
