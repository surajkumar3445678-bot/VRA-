import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_state.dart';
import 'compat.dart';
import 'theme.dart';
import 'widgets.dart';

// 1. Splash --------------------------------------------------------------
class SplashScreen extends StatefulWidget {
  final AppState s;
  const SplashScreen(this.s, {super.key});
  @override
  State<SplashScreen> createState() => _SplashState();
}

class _SplashState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..forward();
  @override
  void initState() {
    super.initState();
    widget.s.init().then((_) {
      Timer(const Duration(milliseconds: 1500), () {
        if (!mounted) return;
        final next = widget.s.onboarded ? HomeScreen(widget.s) : OnboardingScreen(widget.s);
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => next));
      });
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: FadeTransition(
            opacity: _c,
            child: Column(mainAxisSize: MainAxisSize.min, children: const [
              Icon(Icons.shield_outlined, size: 96, color: VraColors.cyan),
              SizedBox(height: 12),
              Text('VRA', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w800, letterSpacing: 6)),
              SizedBox(height: 4),
              Text('VIRTUAL ROOT ANDROID', style: TextStyle(color: VraColors.muted, letterSpacing: 3)),
            ]),
          ),
        ),
      );
}

// 2. Onboarding ----------------------------------------------------------
class OnboardingScreen extends StatefulWidget {
  final AppState s;
  const OnboardingScreen(this.s, {super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingState();
}

class _OnboardingState extends State<OnboardingScreen> {
  int i = 0;
  static const pages = [
    ['A separate Android, not your phone', 'VRA is built to run a guest Android with its own kernel. Your phone stays unrooted.'],
    ['Root that stays in the guest', 'Apps in the guest can be granted virtual root. Nothing here grants root on the host.'],
    ['Honest about limits', 'Many phones cannot run a full guest. VRA checks your hardware first and tells you exactly what is and is not possible.'],
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Spacer(),
              const Icon(Icons.shield_outlined, size: 64, color: VraColors.cyan),
              const SizedBox(height: 20),
              Text(pages[i][0], style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              Text(pages[i][1], style: const TextStyle(fontSize: 16, color: VraColors.muted, height: 1.4)),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () async {
                    if (i < pages.length - 1) {
                      setState(() => i++);
                    } else {
                      await widget.s.setOnboarded();
                      if (!context.mounted) return;
                      Navigator.of(context).pushReplacement(
                          MaterialPageRoute(builder: (_) => HomeScreen(widget.s)));
                    }
                  },
                  child: Text(i < pages.length - 1 ? 'Next' : 'Check my device'),
                ),
              ),
            ]),
          ),
        ),
      );
}

// 3. Dashboard -----------------------------------------------------------
class HomeScreen extends StatelessWidget {
  final AppState s;
  const HomeScreen(this.s, {super.key});

  void _go(BuildContext c, Widget w) =>
      Navigator.of(c).push(MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (context, _) {
          final c = s.compat;
          final tiles = <List<Object>>[
            ['Setup', Icons.memory, SetupScreen(s)],
            ['Boot', Icons.power_settings_new, BootScreen(s)],
            ['Root manager', Icons.admin_panel_settings, RootManagerScreen(s)],
            ['App installer', Icons.apps, InstallerScreen(s)],
            ['Terminal', Icons.terminal, TerminalScreen(s)],
            ['Monitor', Icons.monitor_heart, MonitorScreen(s)],
            ['Google services', Icons.cloud_outlined, GoogleScreen(s)],
            ['Isolation', Icons.lock_outline, IsolationScreen(s)],
            ['Backup', Icons.backup_outlined, BackupScreen(s)],
            ['About', Icons.info_outline, AboutScreen(s)],
          ];
          return VraPage(title: 'VRA', children: [
            VCard(title: 'Virtualization status', children: [
              Row2('Host check', c == null ? 'Not run yet' : c.title),
              Row2('Guest image', s.guestInstalled ? 'Found' : 'Not installed'),
              Row2('Guest state', s.guestRunning ? 'Running' : 'Not running'),
              Row2('Virtual root', 'Unavailable until a guest is running'),
            ]),
            if (c != null && c.mode != VirtMode.kvmQemu) Note(c.explanation),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.5,
              children: [
                for (final t in tiles)
                  InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () => _go(context, t[2] as Widget),
                    child: Container(
                      decoration: BoxDecoration(
                        color: VraColors.card,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: VraColors.cyan.withOpacity(0.25)),
                      ),
                      padding: const EdgeInsets.all(14),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        Icon(t[1] as IconData, color: VraColors.cyan),
                        Text(t[0] as String, style: const TextStyle(fontWeight: FontWeight.w600)),
                      ]),
                    ),
                  ),
              ],
            ),
          ]);
        },
      );
}

// 4. Virtual Android setup / compatibility -------------------------------
class SetupScreen extends StatelessWidget {
  final AppState s;
  const SetupScreen(this.s, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (context, _) {
          final c = s.compat;
          return VraPage(title: 'Virtual Android setup', children: [
            if (c == null)
              const Note('Host probe has not returned data. Tap Re-run check.')
            else ...[
              Note(c.explanation, color: c.mode == VirtMode.kvmQemu ? VraColors.ok : VraColors.warn),
              for (final w in c.warnings) Note(w, color: VraColors.bad),
              VCard(title: 'Host hardware (real device)', children: [
                Row2('Model', c.model),
                Row2('CPU ABI', c.abi),
                Row2('Android SDK', '${c.sdk}'),
                Row2('Host kernel', c.kernel),
                Row2('RAM', '${c.ramMb} MB'),
                Row2('Free storage', '${c.freeStorageMb} MB'),
                Row2('/dev/kvm usable', c.kvmUsable ? 'Yes' : 'No'),
                Row2('AVF feature flag', c.avfFeature ? 'Present (restricted)' : 'Absent'),
              ]),
              VCard(title: 'Chosen route', children: [Text(c.title)]),
            ],
            FilledButton(onPressed: s.refresh, child: const Text('Re-run check')),
          ]);
        },
      );
}

// 5. Boot ----------------------------------------------------------------
class BootScreen extends StatelessWidget {
  final AppState s;
  const BootScreen(this.s, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (context, _) => VraPage(title: 'Virtual system boot', children: [
          VCard(title: 'Required files', children: [
            Row2('Guest image', s.guestInstalled ? 'Found' : 'Missing'),
            Row2('Image path', '${s.guest['imagePath'] ?? '-'}'),
            Row2('QEMU binary', s.guest['qemuPresent'] == true ? 'Found' : 'Missing'),
          ]),
          if (!s.guestInstalled || s.guest['qemuPresent'] != true)
            const Note('Boot needs a licensed ARM64 Android image in the app files folder and a QEMU build (included in this version). See guest_images/README.md.'),
          VCard(title: 'QEMU self-test', children: [
            const Text('Runs the packaged QEMU for a moment and shows what it prints. No guest is started.'),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: s.qemuBusy ? null : s.testQemu,
              child: Text(s.qemuBusy ? 'Running...' : 'Test QEMU'),
            ),
            if (s.qemuOutput != null) ...[
              const SizedBox(height: 8),
              SelectableText(s.qemuOutput!, style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: VraColors.cyan)),
            ],
          ]),
          FilledButton(onPressed: s.boot, child: const Text('Try to boot guest')),
          if (s.bootMessage != null) ...[
            const SizedBox(height: 12),
            Note(s.bootMessage!, color: VraColors.cyan),
          ],
        ]),
      );
}

// 6. Root manager --------------------------------------------------------
class RootManagerScreen extends StatelessWidget {
  final AppState s;
  const RootManagerScreen(this.s, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (context, _) {
          final e = s.root.entries;
          return VraPage(title: 'Root manager', children: [
            const Note('Guest-only policy. A decision here applies inside the guest and never to the host. Enforcement needs the guest su daemon, which is not built yet.', color: VraColors.cyan),
            if (e.isEmpty)
              const VCard(title: 'Authorized apps', children: [Text('No guest app has asked for root yet. Apps appear here after the guest is running.')]),
            for (final x in e)
              VCard(children: [
                Row(children: [
                  Expanded(child: Text(x.package)),
                  Text(x.granted ? 'Granted' : 'Revoked', style: TextStyle(color: x.granted ? VraColors.ok : VraColors.bad)),
                ]),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () {
                      x.granted ? s.root.revoke(x.package) : s.root.grant(x.package);
                      s.saveRoot();
                    },
                    child: Text(x.granted ? 'Revoke' : 'Grant'),
                  ),
                ),
              ]),
            VCard(title: 'Access log', children: [
              if (s.root.log.isEmpty) const Text('No entries.'),
              for (final l in s.root.log.reversed.take(50))
                Text('${l.time.toIso8601String().substring(0, 19)}  ${l.package}  ${l.action}',
                    style: const TextStyle(fontSize: 12, color: VraColors.muted)),
            ]),
          ]);
        },
      );
}

// 7. App installer -------------------------------------------------------
class InstallerScreen extends StatelessWidget {
  final AppState s;
  const InstallerScreen(this.s, {super.key});
  @override
  Widget build(BuildContext context) => VraPage(title: 'App installer', children: [
        const Note('Installing needs a running guest. APKs are only ever installed into the guest, never into this phone.'),
        const VCard(title: 'Installed in guest', children: [Text('Guest is not running, so there is nothing to list.')]),
        const FilledButton(onPressed: null, child: Text('Install APK (guest not running)')),
      ]);
}

// 8. Terminal ------------------------------------------------------------
class TerminalScreen extends StatelessWidget {
  final AppState s;
  const TerminalScreen(this.s, {super.key});
  @override
  Widget build(BuildContext context) => VraPage(title: 'Virtual terminal', children: [
        Container(
          height: 220,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(16)),
          child: const Text('No guest shell. Start a guest to open a terminal.\nThis is not a host shell.',
              style: TextStyle(fontFamily: 'monospace', color: VraColors.cyan)),
        ),
        const SizedBox(height: 12),
        const TextField(enabled: false, decoration: InputDecoration(hintText: 'Guest not running', border: OutlineInputBorder())),
      ]);
}

// 9. System monitor ------------------------------------------------------
class MonitorScreen extends StatelessWidget {
  final AppState s;
  const MonitorScreen(this.s, {super.key});
  @override
  Widget build(BuildContext context) {
    final c = s.compat;
    return VraPage(title: 'System monitor', children: [
      VCard(title: 'Host (real hardware)', children: [
        Row2('CPU ABI', c?.abi ?? '-'),
        Row2('RAM', c == null ? '-' : '${c.ramMb} MB'),
        Row2('Free storage', c == null ? '-' : '${c.freeStorageMb} MB'),
        Row2('Kernel', c?.kernel ?? '-'),
      ]),
      const VCard(title: 'Guest (virtual)', border: VraColors.blue, children: [
        Row2('Android version', 'Guest not running'),
        Row2('Guest kernel', 'Guest not running'),
        Row2('Virtual CPU / RAM', 'Guest not running'),
        Row2('Processes', 'Guest not running'),
        Row2('Network', 'Guest not running'),
      ]),
    ]);
  }
}

// 10. Google services ----------------------------------------------------
class GoogleScreen extends StatelessWidget {
  final AppState s;
  const GoogleScreen(this.s, {super.key});
  @override
  Widget build(BuildContext context) => const VraPage(title: 'Google services setup', children: [
        Note('VRA does not bundle Google apps. Play Store, Play Services and account sign-in only work if you supply a licensed Google-certified guest image.'),
        VCard(title: 'Known limits', children: [
          Text('A self-built guest is not Google-certified. Play Integrity will report it as uncertified, and apps that require it may refuse to run. VRA does not try to hide this.'),
        ]),
        VCard(title: 'Status', children: [Row2('Play Services', 'Not installed'), Row2('Account', 'Not signed in')]),
      ]);
}

// 11. Isolation ----------------------------------------------------------
class IsolationScreen extends StatelessWidget {
  final AppState s;
  const IsolationScreen(this.s, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (context, _) => VraPage(title: 'Isolation settings', children: [
          VCard(title: 'Host to guest sharing (off by default)', children: [
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Allow clipboard sharing'),
              value: s.shareClipboard,
              onChanged: (v) => s.setShare(clipboard: v),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Allow shared folder'),
              value: s.shareFiles,
              onChanged: (v) => s.setShare(files: v),
            ),
            const Text('Saved as policy. It takes effect when a guest runs.', style: TextStyle(color: VraColors.muted)),
          ]),
          const VCard(title: 'Fingerprints a guest can still see', children: [
            Text('A guest can detect virtual hardware, emulated CPU model, VM-style device names and slow timing. These are documented, not hidden. VRA does not spoof device identity or integrity checks.'),
          ]),
        ]),
      );
}

// 12. Backup / restore ---------------------------------------------------
class BackupScreen extends StatelessWidget {
  final AppState s;
  const BackupScreen(this.s, {super.key});
  @override
  Widget build(BuildContext context) => VraPage(title: 'Backup and restore', children: [
        const Note('Guest disk backup needs a guest image. Today you can export the root policy.'),
        FilledButton(
          onPressed: () async {
            await Clipboard.setData(ClipboardData(text: jsonEncode(s.root.toJson())));
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Root policy copied')));
            }
          },
          child: const Text('Copy root policy as JSON'),
        ),
        const SizedBox(height: 8),
        const FilledButton(onPressed: null, child: Text('Back up guest disk (no guest)')),
      ]);
}

// 13. About --------------------------------------------------------------
class AboutScreen extends StatelessWidget {
  final AppState s;
  const AboutScreen(this.s, {super.key});
  @override
  Widget build(BuildContext context) => const VraPage(title: 'About VRA', children: [
        VCard(title: 'VRA 0.1.0 (prototype)', children: [
          Text('Working: hardware compatibility check, guest image detection, guest root policy store, isolation policy, backup of policy.\n\nQEMU is packaged and has a self-test; whether it runs depends on your phone.\n\nNot built yet: guest launch, guest su daemon, guest app installer, guest terminal, guest disk backup.'),
        ]),
      ]);
}
