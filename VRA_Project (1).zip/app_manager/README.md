# app_manager
Phase 3. Needs a running guest: install via guest `pm install`, list via `pm list packages`. Not implemented.
